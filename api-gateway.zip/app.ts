const express=require('express')
const app = express();
const server = require("http").createServer(app);
const io = require("socket.io")(server, { cors: { origin: "*" } });
import { Utility } from "./rmq/utility";
var utility = Utility.getInstance();
var cors = require("cors");
import { default as axios } from "axios";
import { Dictionary } from "dictionaryjs";
import RequestModel from "./Models/RequestModel";
import RequestModelQuery from "./Models/RequestModelQuery";
const port = 5001;
app.use(express.json())
app.use(cors());

let activeDictionary = new Dictionary();

io.on("connection", function (socket) {
   activeDictionary.set("socketID", socket.id);
    socket.emit("generateID", socket.id);
});

function evaluate_service_routes( module_name:string)
{
    let response:string;
    
      switch (module_name) {
        case 'EMPLOYEE': response = 'http://localhost:8000/' + 'Employee';//call Employee Module in HRService
          break;
        case 'DEPARTMENT': response = 'http://localhost:8000/' + 'Department';//call Department Module in HRService
          break;
        case 'EMPLOYEEDEPARTMENT': response = 'http://localhost:8000/' + 'EmployeeDepartment';//call EmployeeDepartment Module in HRService
          break;
        default: return "No Module found";
      }
    
    
    return response;
}

///Get All Request
app.get("home/:module_name/socketID", async (req:any, res:any) => {
  try {
      
      let module_name = req.params.module_name;
      //evaluate url to call via axios
      let url = evaluate_service_routes( module_name)
      console.log(url);
      //axios call
      let result = await axios.get(url);
      console.log(result.data);
      res.status(result.status).send(result.data);
  }
  catch (e) {
      console.log("Error in Axios")
  }

});


///Post Request
app.post("/:module_name/socketID", (req:any, res:any) => {
    const requestModel: RequestModel<any>=req.body;
    const topicName = req.params.module_name + "_ADD";//EMPLOYEE_ADD
    //Publishing (method in Utility.ts)
    const response = utility.PublicMessageToTopic(topicName, requestModel);
    res.json(response);
});


//Put Request
app.put("/:module_name/socketID", (req:any, res:any) => {
    
    const requestModel: RequestModel<any>=req.body;
    const topicName = req.params.module_name + "_UPDATE";   
    const requestModelQuery:RequestModelQuery= req.headers["requestquerymodel"]
    const body = {
        id: JSON.parse(requestModelQuery.filter.conditions[0].field_value),
        requestModel: requestModel,
    }
    //Publishing (method in Utility.ts)
    const response = utility.PublicMessageToTopic(topicName, body);
    res.json(response);
});

//Delete Request
app.delete("/:module_name/socketID", (req:any, res:any) => {
    const requestModelQuery:RequestModelQuery= req.headers["requestquerymodel"]
    let topicName = req.params.module_name + "_DELETE"; 
    //Publishing (method in Utility.ts)
    const response = utility.PublicMessageToTopic(topicName,requestModelQuery);
    res.json(response);
});


///Server //it is also listening to the Utility(Broker) method listenToServices(which listens all the services to which API-Gateway is subscriber) 
server.listen(port, () => {
    console.log("Server Runnig on : ", port);
    utility.listenToServices("API_GATEWAY_SERVICE", (result:any) => {
        const { message } = result;
        console.log(message);
    });
});








